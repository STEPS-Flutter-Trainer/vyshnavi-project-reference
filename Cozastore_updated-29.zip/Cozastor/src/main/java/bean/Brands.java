package bean;

public class Brands {
	
	private int id;
	private String brandName;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrand_name(String brandName) {
		this.brandName = brandName;
	}
	

}